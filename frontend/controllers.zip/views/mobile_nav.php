<div class="container-fluid tertiary-nav hidden-lg hidden-md">
	<div class="row">
	<div class="col-xs-12">
				<div class="padding-reset">
				<div class="col-xs-3">
					<a class="tertiary-nav__item" href="fullbody_massage.html">
						<span class="tertiary-nav__icon">
						  <img class="margin-b-s margin-t-s" width="30" src="<?php echo base_url();?>assets/images/nav/nav1.png">
						</span>
						<p class="tertiary-nav__desc">Spa & <br>massage</p>
					</a>
				</div>
				<div class="col-xs-3">
				<a class="tertiary-nav__item" href="haircut.html">
					<span class="tertiary-nav__icon">
					  <img class="margin-b-s margin-t-s" width="30" src="<?php echo base_url();?>assets/images/nav/nav2.png">
					</span>
					<p class="tertiary-nav__desc">Unisex<br> Saloons</p>
				</a>
				</div>
				<div class="col-xs-3">
				<a class="tertiary-nav__item" href="packages.html">
					<span class="tertiary-nav__icon">
					  <img class="margin-b-s margin-t-s" width="30" src="<?php echo base_url();?>assets/images/nav/nav3.png">
					</span>
					<p class="tertiary-nav__desc">Packages</p>
				</a>
				</div>
				<div class="col-xs-3">
				<a class="tertiary-nav__item navmore" href="javascript:void(0)">
					<span class="tertiary-nav__icon">
					  <img class="margin-b-s margin-t-s" width="30" src="<?php echo base_url();?>assets/images/nav/nav7.png">
					</span>
					<p class="tertiary-nav__desc">More</p>
				</a>
				</div>
				<!-- <div class="readmore"> -->
					<!-- <a class="tertiary-nav__item"> -->
						<!-- <span class="tertiary-nav__icon more"></span> -->
						<!-- <p class="tertiary-nav__desc">More</p> -->
					<!-- </a>															 -->
				<!-- </div> -->
			</div>
		
			
		<cat-nav-modal> 
		<div class="overlay overlay-category bg-white">
		  <div class="overlay__content">
			<div class="overlay__header overlay__header--no-bg">
			  <div class="fl-row">
			  
				<div class="fl-column closenav ml20">
				  <button class="btn btn-icon btn--circle color-white">
					<i class="fa fa-close"></i>
				  </button>
				  
				</div>
				<div class="fl-column pull-right mr20" onclick="pageRedirect()">
				  <button class="btn btn-icon btn--circle color-white">
					<i class="fa fa-arrow-left"></i>
				  </button>
				  
				</div>
				
			  </div>
			</div>
			<div class="wrapper">
			  <div class="section">
				
			  </div>
			  <div class="section">
				<div class="fl-row fl-row--wrap tertiary-nav tertiary-nav--secondary tertiary-nav--border"> 
				  <a class="tertiary-nav__item" href="fullbody_massage.html">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav1.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">Spa & massage</p>
					  </div>
					</div>
				  </a>
				  <a class="tertiary-nav__item" href="haircut.html">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav2.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">Unisex Saloons</p>
					  </div>
					</div>
				  </a>
				  <a class="tertiary-nav__item" href="packages.html">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav3.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">Packages</p>
					  </div>
					</div>
				  </a>
				  <a class="tertiary-nav__item" href="women_body.html">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav4.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">Saloon @ home for women</p>
					  </div>
					</div>
				  </a>
				  <a class="tertiary-nav__item" href="saloon_products.html">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav5.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">Products</p>
					  </div>
					</div>
				  </a>
				  <a class="tertiary-nav__item" href="javascript:void(0)">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav6.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">Beauty & Wellness</p>
					  </div>
					</div>
				  </a>
				  <a class="tertiary-nav__item" href="javascript:void(0)">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav8.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">More Events</p>
					  </div>
					</div>
				  </a>
				  <a class="tertiary-nav__item" href="javascript:void(0)">
					<div class="fl-row fl-row--start fl-row--gutter fl-row--middle">
					  <div class="fl-column">
						  <span class="tertiary-nav__icon ">
							<img class="margin-t-s" width="24" src="<?php echo base_url();?>assets/images/nav/nav9.png">
						  </span>
					  </div>
					  <div class="fl-column">
						 <p class="tertiary-nav__desc">Health & Fitness</p>
					  </div>
					</div>
				  </a>
				  
				  
				</div>
			  </div>
			</div> 
		  </div>
		</div>
		</cat-nav-modal>
	</div>
	</div>
</div>